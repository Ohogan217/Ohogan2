public enum Suit {//enum of the different card suits
    Hearts ,
    Spades,
    Diamonds ,
    Clubs ;
}
