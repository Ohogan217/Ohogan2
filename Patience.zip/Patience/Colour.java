public enum Colour {//enumerator for the different card colouts
    red,
    black
}
